@extends('Admin.Layout.layout')
@section('content')
    <div class="container-fluid">
        <h1>asdasd</h1>
    </div>
@endsection
