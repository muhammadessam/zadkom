@extends('layouts.myapp')
@section('content')
<div class="row store-title" style="background-image:url({{asset('images/bg1.png')}});    background-attachment: fixed;">
    اصناف متجر 11
</div>
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="product" style="background-image:url({{asset('images/bg1.png')}});">
                <h4>سمك مقلي جاهز</h4>
                <p>13.99$</p>
                <a class="btn btn-info" href="#">التفاصيل</a>
            </div>
        </div>
    </div>
</div>
@endsection